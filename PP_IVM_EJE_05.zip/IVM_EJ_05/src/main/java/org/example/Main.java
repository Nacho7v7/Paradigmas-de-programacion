package org.example;

import java.util.Scanner;

// link de github -- https://github.com/Nacho7v7/Paradigmas-de-programacion
public class Main {
    public static void main(String[] args) {
        //Pruebas Unitarias
        int opcion = 0;
        while (opcion != 5) {
            opcion = menu();
            switch (opcion) {
                case 1:
                    //Programacion Funcional - Declarrativa
                    muestraResultados("El resultado de la suma es: ",
                            suma(numeroTeclado(), numeroTeclado()));
                    break;
                case 2:
                    //Programación Estructurada - Imperativa
                    float n1 = numeroTeclado();
                    float n2 = numeroTeclado();
                    float r = resta(n1,n2);

                    muestraResultados("El resultado de la resta es ",r);
                    break;

                case 3:
                    //Programación Funcional - Declarativa
                    muestraResultados("El resultado de la multiplicacion es: ",
                            multiplicacion(numeroTeclado(), numeroTeclado()));
                    break;

                case 4:
                    //Programación Estructurada - Imperativa
                    float num1 = numeroTeclado();
                    float num2 = numeroTeclado();
                    float res = division(num1, num2);

                    muestraResultados("El resultado de la division es: ", res);
                    break;
                case 5:
                    System.out.println("Saliendo del programa...");
                    break;

                default:
                    System.out.println("Opción no válida. Intenta de nuevo.");
                    break;

            }
        }
    }

    // funcion menu - int1
    public static int menu() {
        Scanner sc = new Scanner(System.in);
        System.out.println("1.- Suma");
        System.out.println("2.- Resta ");
        System.out.println("3.- Multiplicacion");
        System.out.println("4.- Division");
        System.out.println("5.- Salir");
        System.out.println("Elige un numero: ");
        int opcion = sc.nextInt();
        return opcion;
    }

    // funcion suma - float
    public static float suma(float a, float b) {
        return a + b;
    }

    //Función resta - float
    public static float resta(float n1, float n2)
    {
        return n1-n2;
    }
    //Función multiplicación - float
    public static float multiplicacion(float n1, float n2)
    {
        return n1 * n2;
    }
    //Función división - float
    public static float division(float n1, float n2)
    {
        if (n2 == 0)
        {
            System.out.println("Error: No se puede dividir entre cero.");
            return 0;
        }
        return n1 / n2;
    }

    //funcion ingresar numero - float
    public static float numeroTeclado() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el numero: ");
        float numero = sc.nextFloat();
        return numero;
    }

    // funcion regresar resultado - float
    public static void muestraResultados(String mensaje, float resultado) {
        System.out.println(mensaje + " :" + resultado);
    }
}
