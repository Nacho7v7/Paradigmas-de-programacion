package org.example;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;

//package org.upiiz;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main
{
    // metodo principal - main
    public static void main(String[] args)
    {
        // int - tipo de dato primitivo

        // integer - clase que maneja el dato primitivo
        List<Integer>listadonumeros;

        // iniciar las clases
        listadonumeros = new ArrayList<>();
        int opcion=0;
        while (opcion!=7)
        {
            opcion=menu();
            switch (opcion)
            {
                case 1: leerdato(listadonumeros);
                break;
                case 2: numerospares(listadonumeros);
                break;
                case 3:
                    List<Integer> resultadoCuadrados = cuadradoValores(listadonumeros);
                    System.out.println("Los cuadrados de los valores son: " + resultadoCuadrados);
                    break;
                case 4: int suma = sumanumeros(listadonumeros);
                System.out.println("la suma es: "+suma);
                break;
                // case 5:
                  //  System.out.println("Ingresa el elemento que deseas buscar:");
                //    Object sc;
                  //  int buscado = sc.nextline();
                 //   boolean encontrado = buscarelemento(listadonumeros, buscado);
                //    if (encontrado) {
                  //      System.out.println("El elemento sí se encuentra en la lista.");
                //    } else {
                  //      System.out.println("El elemento no está en la lista.");
                   // }
                   // break;

                case 6:
                    int max = encontrarmaximo(listadonumeros);
                    System.out.println("El valor máximo en la lista es: " + max);
                    break;

                case 7: // O el número que corresponda a tu opción de salida
                    salir();
                    break;
            }
        }
    }
    //



    // funcion - leer datos
    public static void leerdato(List<Integer>listado)
    //inicio, fin, incremento
    {
       Scanner sc = new Scanner(System.in);
       System.out.println(" digita un numero:  ");
       int numero = sc.nextInt();
       listado.add(numero);
    }

    // funcion - numeros pares
    public static void numerospares(List<Integer> listado)
    {
        //inicio, fin, incremento
        // programacion estructurada
        for(int i=0;i<listado.size();i++)
            if (listado.get(i) % 2 == 0)
            {
                int numeropar=listado.get(i);
                System.out.println(numeropar);

            }
    }

    // funcion cuadrado de los valores
    public static List<Integer> cuadradoValores(List<Integer> listado)
    {
        List<Integer> cuadrados = new ArrayList<>();
        for (int i = 0; i < listado.size(); i++)
        {
            int valor = listado.get(i);
            cuadrados.add(valor * valor);
        }
        return cuadrados;
    }

    // funcion suma de numeros
    public static int sumanumeros(List<Integer> listado)
    {
        int suma = 0;
        for( int i=0; i<listado.size();i++)
        {
            suma = suma+ listado.get(i);
        }
        return suma;
    }

    // funcion buscar un elemento en la lista
    public static boolean buscarelemento(List<Integer> listado, int elementobuscado)
    {
        for (int i = 0; i < listado.size(); i++)
        {
            if (listado.get(i) == elementobuscado)
            {
                return true; // encontrado
            }
        }
        return false; // No encontrado
    }

    // funcion encontrar el valor maximo
    public static int encontrarmaximo(List<Integer> listado)
    {
        if (listado == null || listado.isEmpty())
        {
            throw new IllegalArgumentException("La lista está vacía");
        }

        int maximo = listado.get(0);
        for (int i = 1; i < listado.size(); i++)
        {
            if (listado.get(i) > maximo)
            {
                maximo = listado.get(i);
            }
        }
        return maximo;
    }

    // funcion salir
    public static void salir()
    {
        System.out.println("¡Hasta luego!");
    }

    public static int menu()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("1.- leer datos.");
        System.out.println("2.- muestre numeros pares");
        System.out.println("3.- muestre los cuadrados de los valores");
        System.out.println("4.- suma de los elementos de la lista");
        System.out.println("5.- buscar un elemento de la lista");
        System.out.println("6.- encontrar el valor maximo");
        System.out.println("7.- salir");
        int opcion = sc.nextInt();
        return opcion;

    }
}

